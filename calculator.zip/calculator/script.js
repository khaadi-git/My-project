
let num1 = document.getElementById("num1");
let num2 = document.getElementById("num2");
let result = document.getElementById("result");

function Add() {
    let a = Number(num1.value);
    let b = Number(num2.value);

    let sum = a + b;
    result.innerText = sum;
}

function Subtract() {
    let a = Number(num1.value);
    let b = Number(num2.value);

    let answer = a - b;
    result.innerText = answer;
}

function Multiply() {
    let a = Number(num1.value);
    let b = Number(num2.value);

    let answer = a * b;
    result.innerText = answer;
}

function Divide() {
    let a = Number(num1.value);
    let b = Number(num2.value);

    if (b === 0) {
        result.innerText = "Cannot divide by zero";
    } else {
        let answer = a / b;
        result.innerText = answer;
    }
}
